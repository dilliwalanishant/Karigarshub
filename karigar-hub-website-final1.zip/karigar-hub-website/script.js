document.addEventListener('DOMContentLoaded', function () {
    
    // --- BILINGUAL & DYNAMIC CONTENT SCRIPT ---
    const languageData = {
        en: {
            pageTitle: "KARIGAR's HUB", headerTitle: "KARIGAR's HUB", headerSubtitle: "A Single Portal to Empower Weavers of Taraboi",
            navHome: "Home", navLearn: "Learn", navSchemes: "Schemes", navSell: "Sell Craft", navEducation: "For Children", navSupport: "Support",
            eventTitle: "Upcoming Event", eventName: "Toshali National Crafts Mela", eventDateLabel: "Date:", eventDate: "15th - 28th December", eventLocationLabel: "Location:", eventLocation: "Bhubaneswar", eventDesc: "A great opportunity to showcase and sell your products. We can help with stall applications.",
            missionTitle: "Our Mission", missionText: "To provide the weavers of Taraboi with the digital tools, knowledge, and platform needed to grow their craft, improve their livelihood, and stand on their own feet.",
            joinHubTitle: "Join Karigar Hub Today!",
            learnTitle: "Learn & Grow", successStoriesTitle: "Artisan Success Stories", successStoriesText: "Watch videos from weavers in our community who have benefited from this portal.", howToSellTitle: "How to Sell Your Products Online", howToSellText: "A detailed tutorial on taking good photos, writing descriptions, and managing online sales.", tutorialUpiTitle: "How to Use UPI", tutorialUpiText: "Learn to receive payments directly from customers using your phone.",
            aiFinderTitle: "AI Scheme Finder", findSchemeText: "Answer a few questions and our AI tool will suggest the best government schemes for you.", artisanIdLabel: "Do you have an Artisan ID Card (Pehchan Card)?", yes: "Yes", no: "No", enterIdLabel: "Please enter your 12-digit Artisan ID:", ageLabel: "What is your age?", agePlaceholder: "e.g., 45", needLabel: "What do you need help with?", selectOption: "-- Select an Option --", needLoan: "Loan for Business", needTraining: "New Design Training", needPension: "Pension for Old Age", needEducation: "Child's Education", findSchemesBtn: "Find My Schemes",
            onlineShopTitle: "Your Online Shop", microStorefrontsTitle: "E-Commerce Micro-Storefronts", microStorefrontsText: "Enable direct B2C sales without leaving the portal. Register to get your own personal webpage to showcase your products and tell your story.", upiPaymentsTitle: "Auto-Generated UPI QR Codes", upiPaymentsText: "Our digital payment gateway creates a unique UPI QR code for your shop, enabling faster, cash-less transactions at fairs and online.", 
            regName: "Full Name:", regPhone: "Phone Number:", regLocation: "Village/Address:", regCraft: "Type of Weaving:", regCraftPlaceholder: "e.g., Bomkai, Sambalpuri", regSubmitBtn: "Register Now",
            childrensFutureTitle: "A Bright Future for Our Children", centralGovtSchol: "Central Government Scholarships", nsp: "National Scholarship Portal (NSP)", nspDesc: "A single portal for various scholarships from the central government.", odishaGovtSchol: "Odisha State Scholarships", osp: "Odisha State Scholarship Portal", ospDesc: "The main portal for scholarships offered by the Government of Odisha.", sams: "SAMS Odisha", samsDesc: "Student Academic Management System for admissions and e-Administration in Odisha.", ngoSchol: "NGO Educational Support", ngo1: "Kalinga Institute of Social Sciences (KISS)", ngo1Desc: "Provides free education from KG to PG for tribal children.", ngo2: "Adhikar", ngo2Desc: "Works on livelihood and educational rights in Odisha.",
            partnersTitle: "Partners & Support", govtPortalsTitle: "Important Government Portals", portalMinHT: "Ministry of Handlooms and Textiles", portalMinHTDesc: "Official portal for central government schemes and information.", portalOdishaOne: "Odisha One", portalOdishaOneDesc: "A single application for over 100 government services in Odisha.", portalBoyanika: "Boyanika", portalBoyanikaDesc: "The official e-commerce platform for Odisha Handloom products.",
            footerOfflineText: "Portal works even with a weak signal. Install the app for offline use!", footerCopyright: "© 2025 Karigar's Hub | Designed to Uplift the Weavers of Taraboi.",
            voiceListening: "Listening...", chatHeader: "Support Hub",
            chatWelcome: "Hello! How can I help you today?",
            chatFaq1: "How to get a loan?", chatFaq2: "How to sell my products?", chatFaq3: "How to find scholarships?", chatFaq4: "Need direct help?",
            chatAns1: "You can apply for a loan through the MUDRA scheme. Our 'AI Scheme Finder' on the 'Schemes' page can give you more details.",
            chatAns2: "Register on our 'Sell Craft' page. We will help you create your own online shop to sell directly to customers.",
            chatAns3: "Visit the 'For Children' page. We have links to the National Scholarship Portal and state portals for various educational scholarships.",
            chatAns4: "For direct help, you can use the IVR Support or WhatsApp Bot links at the top of the Support page.",
            welcomeTitle: "Welcome to Karigar's Hub!", welcomeText: "Are you a new user? We have a short video to show you how to use the website.", watchTutorialBtn: "Watch Tutorial", noThanksBtn: "No, thanks", siteTutorialTitle: "How to use Karigar's Hub",
        },
        or: {
            pageTitle: "କାରିଗର ହବ୍", headerTitle: "କାରିଗର ହବ୍", headerSubtitle: "ତାରାବୋଇର ବୁଣାକାରମାନଙ୍କୁ ସଶକ୍ତ କରିବା ପାଇଁ ଏକକ ପୋର୍ଟାଲ୍",
            navHome: "ମୁଖ୍ୟ ପୃଷ୍ଠା", navLearn: "ଶିଖନ୍ତୁ", navSchemes: "ଯୋଜନା", navSell: "ବିକ୍ରି କରନ୍ତୁ", navEducation: "ପିଲାଙ୍କ ପାଇଁ", navSupport: "ସହାୟତା",
            eventTitle: "ଆଗାମୀ କାର୍ଯ୍ୟକ୍ରମ", eventName: "ତୋଷାଳୀ ଜାତୀୟ ହସ୍ତଶିଳ୍ପ ମେଳା", eventDateLabel: "ତାରିଖ:", eventDate: "୧୫ - ୨୮ ଡିସେମ୍ବର", eventLocationLabel: "ସ୍ଥାନ:", eventLocation: "ଭୁବନେଶ୍ୱର", eventDesc: "ଆପଣଙ୍କ ଉତ୍ପାଦ ପ୍ରଦର୍ଶନ ଏବଂ ବିକ୍ରୟ ପାଇଁ ଏକ ବଡ଼ ସୁଯୋଗ।",
            missionTitle: "ଆମର ଲକ୍ଷ୍ୟ", missionText: "ତାରାବୋଇର ବୁଣାକାରମାନଙ୍କୁ ଡିଜିଟାଲ୍ ଉପକରଣ, ଜ୍ଞାନ ଏବଂ ପ୍ଲାଟଫର୍ମ ପ୍ରଦାନ କରିବା।",
            joinHubTitle: "ଆଜି ହିଁ କାରିଗର ହବ୍‌ରେ ଯୋଗ ଦିଅନ୍ତୁ!",
            learnTitle: "ଶିଖନ୍ତୁ ଓ ଆଗକୁ ବଢନ୍ତୁ", successStoriesTitle: "କାରିଗରଙ୍କ ସଫଳତା କାହାଣୀ", successStoriesText: "ଆମ ସମ୍ପ୍ରଦାୟର ବୁଣାକାରମାନଙ୍କ ଭିଡିଓ ଦେଖନ୍ତୁ ଯେଉଁମାନେ ଏହି ପୋର୍ଟାଲରୁ ଲାଭ ପାଇଛନ୍ତି।", howToSellTitle: "ଅନଲାଇନରେ ଆପଣଙ୍କ ଉତ୍ପାଦ କିପରି ବିକ୍ରି କରିବେ", howToSellText: "ଭଲ ଫଟୋ ଉଠାଇବା, ବିବରଣୀ ଲେଖିବା ଏବଂ ଅନଲାଇନ୍ ବିକ୍ରୟ ପରିଚାଳନା କରିବା ଉପରେ ଏକ ବିସ୍ତୃତ ଟ୍ୟୁଟୋରିଆଲ୍।", tutorialUpiTitle: "UPI କିପରି ବ୍ୟବହାର କରିବେ", tutorialUpiText: "ଗ୍ରାହକଙ୍କଠାରୁ ସିଧାସଳଖ ଆପଣଙ୍କ ଫୋନ୍ ବ୍ୟବହାର କରି ପେମେଣ୍ଟ ଗ୍ରହଣ କରିବା ଶିଖନ୍ତୁ।",
            aiFinderTitle: "AI ସ୍କିମ୍ ଫାଇଣ୍ଡର୍", findSchemeText: "କିଛି ପ୍ରଶ୍ନର ଉତ୍ତର ଦିଅନ୍ତୁ ଏବଂ ଆମର AI ଉପକରଣ ଆପଣଙ୍କ ପାଇଁ ସର୍ବୋତ୍ତମ ସରକାରୀ ଯୋଜନାଗୁଡିକର ପରାମର୍ଶ ଦେବ।", artisanIdLabel: "ଆପଣଙ୍କ ପାଖରେ କାରିଗର ପରିଚୟ ପତ୍ର (ପେହଚାନ୍ କାର୍ଡ) ଅଛି କି?", yes: "ହଁ", no: "ନାହିଁ", enterIdLabel: "ଦୟାକରି ଆପଣଙ୍କ ୧୨-ଅଙ୍କ ବିଶିଷ୍ଟ କାରିଗର ID ପ୍ରବେଶ କରନ୍ତୁ:", ageLabel: "ଆପଣଙ୍କ ବୟସ କେତେ?", agePlaceholder: "ଉଦାହରଣ, ୪୫", needLabel: "ଆପଣଙ୍କୁ କେଉଁଥିରେ ସାହାଯ୍ୟ ଦରକାର?", selectOption: "-- ଏକ ବିକଳ୍ପ ବାଛନ୍ତୁ --", needLoan: "ବ୍ୟବସାୟ ପାଇଁ ଋଣ", needTraining: "ନୂଆ ଡିଜାଇନ୍ ତାଲିମ", needPension: "ବୃଦ୍ଧାବସ୍ଥା ପାଇଁ ପେନସନ", needEducation: "ପିଲାର ଶିକ୍ଷା", findSchemesBtn: "ମୋ ପାଇଁ ଯୋଜନା ଖୋଜନ୍ତୁ",
            onlineShopTitle: "ଆପଣଙ୍କ ଅନଲାଇନ୍ ଦୋକାନ", microStorefrontsTitle: "ଇ-କମର୍ସ ମାଇକ୍ରୋ-ଷ୍ଟୋରଫ୍ରଣ୍ଟସ୍", microStorefrontsText: "ପୋର୍ଟାଲ୍ ନଛାଡି ସିଧାସଳଖ B2C ବିକ୍ରୟ ସକ୍ଷମ କରନ୍ତୁ। ଆପଣଙ୍କ ଉତ୍ପାଦ ପ୍ରଦର୍ଶନ ଏବଂ କାହାଣୀ କହିବା ପାଇଁ ନିଜର ବ୍ୟକ୍ତିଗତ ୱେବପେଜ୍ ପାଇବାକୁ ପଞ୍ଜୀକରଣ କରନ୍ତୁ।", upiPaymentsTitle: "ସ୍ଵୟଂ-ଉତ୍ପାଦିତ UPI QR କୋଡ୍", upiPaymentsText: "ଆମର ଡିଜିଟାଲ୍ ପେମେଣ୍ଟ୍ ଗେଟୱେ ଆପଣଙ୍କ ଦୋକାନ ପାଇଁ ଏକ ଅନନ୍ୟ UPI QR କୋଡ୍ ସୃଷ୍ଟି କରେ।", 
            regName: "ପୂରା ନାମ:", regPhone: "ଫୋନ୍ ନମ୍ବର:", regLocation: "ଗାଁ/ঠিকଣା:", regCraft: "ବୁଣାକାର ପ୍ରକାର:", regCraftPlaceholder: "ଉଦାହରଣ, ବୋମକାଇ, ସମ୍ବଲପୁରୀ", regSubmitBtn: "ବର୍ତ୍ତମାନ ପଞ୍ଜୀକରଣ କରନ୍ତୁ",
            childrensFutureTitle: "ଆମ ପିଲାମାନଙ୍କ ପାଇଁ ଏକ ଉଜ୍ଜ୍ୱଳ ଭବିଷ୍ୟତ", centralGovtSchol: "କେନ୍ଦ୍ର ସରକାରୀ ଛାତ୍ରବୃତ୍ତି", nsp: "ଜାତୀୟ ଛାତ୍ରବୃତ୍ତି ପୋର୍ଟାଲ୍ (NSP)", nspDesc: "କେନ୍ଦ୍ର ସରକାରଙ୍କ ବିଭିନ୍ନ ଛାତ୍ରବୃତ୍ତି ପାଇଁ ଏକକ ପୋର୍ଟାଲ୍।", odishaGovtSchol: "ଓଡିଶା ରାଜ୍ୟ ଛାତ୍ରବୃତ୍ତି", osp: "ଓଡିଶା ରାଜ୍ୟ ଛାତ୍ରବୃତ୍ତି ପୋର୍ଟାଲ୍", ospDesc: "ଓଡିଶା ସରକାରଙ୍କ ଦ୍ୱାରା ପ୍ରଦତ୍ତ ଛାତ୍ରବୃତ୍ତି ପାଇଁ ମୁଖ୍ୟ ପୋର୍ଟାଲ୍।", sams: "ସାମ୍ସ ଓଡିଶା", samsDesc: "ଓଡିଶାରେ ଆଡମିଶନ ଏବଂ ଇ-ପ୍ରଶାସନ ପାଇଁ ଛାତ୍ର ଏକାଡେମିକ୍ ମ୍ୟାନେଜମେଣ୍ଟ ସିଷ୍ଟମ୍।", ngoSchol: "ଏନଜିଓ ଶିକ୍ଷାଗତ ସହାୟତା", ngo1: "କଳିଙ୍ଗ ଇନଷ୍ଟିଚ୍ୟୁଟ୍ ଅଫ୍ ସୋସିଆଲ୍ ସାଇନ୍ସେସ୍ (KISS)", ngo1Desc: "ଆଦିବାସୀ ପିଲାମାନଙ୍କ ପାଇଁ KG ରୁ PG ପର୍ଯ୍ୟନ୍ତ ମାଗଣା ଶିକ୍ଷା ପ୍ରଦାନ କରେ।", ngo2: "ଅଧିକାର", ngo2Desc: "ଓଡିଶାରେ ଜୀବିକା ଏବଂ ଶିକ୍ଷାଗତ ଅଧିକାର ଉପରେ କାର୍ଯ୍ୟ କରେ।",
            partnersTitle: "ଭାଗିଦାରୀ ଏବଂ ସହାୟତା", govtPortalsTitle: "ଗୁରୁତ୍ୱପୂର୍ଣ୍ଣ ସରକାରୀ ପୋର୍ଟାଲ୍", portalMinHT: "ବୟନଶିଳ୍ପ ମନ୍ତ୍ରାଳୟ", portalMinHTDesc: "କେନ୍ଦ୍ର ସରକାରଙ୍କ ଯୋଜନା ଏବଂ ସୂଚନା ପାଇଁ ସରକାରୀ ପୋର୍ଟାଲ୍।", portalOdishaOne: "ଓଡିଶା ୱାନ୍", portalOdishaOneDesc: "ଓଡିଶାରେ ୧୦୦ରୁ ଅଧିକ ସରକାରୀ ସେବା ପାଇଁ ଏକକ ଆପ୍ଲିକେସନ୍।", portalBoyanika: "ବୟନିକା", portalBoyanikaDesc: "ଓଡିଶା ହସ୍ତତନ୍ତ ଉତ୍ପାଦ ପାଇଁ ସରକାରୀ ଇ-କମର୍ସ ପ୍ଲାଟଫର୍ମ।",
            footerOfflineText: "କମ୍ ସିଗନାଲରେ ବି ପୋର୍ଟାଲ୍ କାମ କରେ। ଅଫଲାଇନ୍ ବ୍ୟବହାର ପାଇଁ ଆପ୍ ଇନଷ୍ଟଲ୍ କରନ୍ତୁ!", footerCopyright: "© ୨୦୨୫ କାରିଗର ହବ୍ | ତାରାବୋଇର ବୁଣାକାରମାନଙ୍କ ଉନ୍ନତି ପାଇଁ ପରିକଳ୍ପିତ।",
            voiceListening: "ଶୁଣୁଛି...", chatHeader: "ସହାୟତା କେନ୍ଦ୍ର",
            chatWelcome: "ନମସ୍କାର! ମୁଁ ଆଜି ଆପଣଙ୍କୁ କିପରି ସାହାଯ୍ୟ କରିପାରେ?",
            chatFaq1: "ଋଣ କିପରି ପାଇବି?", chatFaq2: "ମୋ ଉତ୍ପାଦ କିପରି ବିକ୍ରି କରିବି?", chatFaq3: "ଛାତ୍ରବୃତ୍ତି କିପରି ପାଇବି?", chatFaq4: "ସିଧାସଳଖ ସାହାଯ୍ୟ ଦରକାର କି?",
            chatAns1: "ଆପଣ ମୁଦ୍ରା ଯୋଜନା ମାଧ୍ୟମରେ ଋଣ ପାଇଁ ଆବେଦନ କରିପାରିବେ। ଆମ 'ଯୋଜନା' ପୃଷ୍ଠାରେ ଥିବା 'AI ସ୍କିମ୍ ଫାଇଣ୍ଡର୍' ଆପଣଙ୍କୁ ଅଧିକ ବିବରଣୀ ଦେଇପାରିବ।",
            chatAns2: "'ବିକ୍ରି କରନ୍ତୁ' ପୃଷ୍ଠାରେ ପଞ୍ଜୀକରଣ କରନ୍ତୁ। ଆମେ ଆପଣଙ୍କୁ ନିଜର ଅନଲାଇନ୍ ଦୋକାନ ସୃଷ୍ଟି କରିବାରେ ସାହାଯ୍ୟ କରିବୁ।",
            chatAns3: "'ପିଲାଙ୍କ ପାଇଁ' ବିଭାଗକୁ ଯାଆନ୍ତୁ। ଆମ ପାଖରେ ବିଭିନ୍ନ ଶିକ୍ଷାଗତ ଛାତ୍ରବୃତ୍ତି ପାଇଁ ଜାତୀୟ ଛାତ୍ରବୃତ୍ତି ପୋର୍ଟାଲର ଲିଙ୍କ୍ ଅଛି।",
            chatAns4: "ସିଧାସଳଖ ସାହାଯ୍ୟ ପାଇଁ, ଆପଣ ସହାୟତା ପୃଷ୍ଠାର ଶୀର୍ଷରେ ଥିବା IVR ସହାୟତା କିମ୍ବା ହ୍ଵାଟ୍ସଆପ୍ ବଟ୍ ଲିଙ୍କ୍ ବ୍ୟବହାର କରିପାରିବେ।",
            welcomeTitle: "କାରିଗର ହବ୍‌କୁ ସ୍ୱାଗତ!", welcomeText: "ଆପଣ ଜଣେ ନୂଆ ବ୍ୟବହାରକାରୀ କି? ୱେବସାଇଟ୍ କିପରି ବ୍ୟବହାର କରିବେ ତାହା ଦେଖାଇବା ପାଇଁ ଆମ ପାଖରେ ଏକ ଛୋଟ ଭିଡିଓ ଅଛି।", watchTutorialBtn: "ଟ୍ୟୁଟୋରିଆଲ୍ ଦେଖନ୍ତୁ", noThanksBtn: "ନା, ଧନ୍ୟବାଦ", siteTutorialTitle: "କାରିଗର ହବ୍ କିପରି ବ୍ୟବହାର କରିବେ",
        }
    };

    const translatableElements = {};
    document.querySelectorAll('[data-key]').forEach(el => {
        const key = el.dataset.key;
        if (!translatableElements[key]) translatableElements[key] = [];
        translatableElements[key].push(el);
    });
    
    const mainSupportBtn = document.getElementById('main-support-btn');
    const chatbotContainer = document.getElementById('chatbot-container');
    const closeChatbotBtn = document.getElementById('close-chatbot-btn');
    const chatbotMessages = document.getElementById('chatbot-messages');
    const chatbotFaqOptions = document.getElementById('chatbot-faq-options');

    let currentLanguage;

    function addMessageToChat(text, type) {
        const messageElement = document.createElement('div');
        messageElement.className = `${type}-message`;
        messageElement.textContent = text;
        chatbotMessages.appendChild(messageElement);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }

    function initializeChatbot() {
        chatbotMessages.innerHTML = '';
        chatbotFaqOptions.innerHTML = '';
        const lang = currentLanguage;
        addMessageToChat(languageData[lang].chatWelcome, 'bot');
        const faqs = [ { q: languageData[lang].chatFaq1, a: languageData[lang].chatAns1 }, { q: languageData[lang].chatFaq2, a: languageData[lang].chatAns2 }, { q: languageData[lang].chatFaq3, a: languageData[lang].chatAns3 }, { q: languageData[lang].chatFaq4, a: languageData[lang].chatAns4 } ];
        faqs.forEach(faq => {
            const faqButton = document.createElement('button');
            faqButton.className = 'faq-btn';
            faqButton.textContent = faq.q;
            faqButton.addEventListener('click', () => {
                addMessageToChat(faq.q, 'user');
                setTimeout(() => addMessageToChat(faq.a, 'bot'), 400);
            });
            chatbotFaqOptions.appendChild(faqButton);
        });
    }

    function updateLanguage(lang) {
        currentLanguage = lang;
        document.documentElement.lang = lang;
        localStorage.setItem('preferredLanguage', lang);

        for (const key in translatableElements) {
            const textData = languageData[lang][key];
            if (textData === undefined) continue;
            translatableElements[key].forEach(el => {
                const icon = el.querySelector('i');
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    if (el.type === 'submit' || el.type === 'button') el.value = textData;
                    else el.placeholder = textData;
                } else if (icon && el.dataset.key) {
                    el.innerHTML = icon.outerHTML + ' ' + textData;
                } else {
                    el.textContent = textData;
                }
            });
        }

        if (chatbotContainer && chatbotContainer.style.display === 'flex') {
            initializeChatbot();
        } else if (chatbotContainer) {
            chatbotMessages.innerHTML = '';
            chatbotFaqOptions.innerHTML = '';
        }
    }
    
    // --- MODAL & POPUP LOGIC ---
    const allModals = document.querySelectorAll('.modal');
    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        if(modal) modal.style.display = 'block';
    }
    function closeModal(modal) {
        if(modal) modal.style.display = 'none';
    }
    allModals.forEach(modal => {
        // Close button inside the modal
        modal.querySelector('.close-btn')?.addEventListener('click', () => closeModal(modal));
    });
    // Close by clicking outside
    window.addEventListener('click', event => {
        if (event.target.classList.contains('modal')) {
            closeModal(event.target);
        }
    });

    // --- INITIALIZATION ON PAGE LOAD ---

    const savedLanguage = localStorage.getItem('preferredLanguage') || 'en';
    const langToggle = document.getElementById('language-toggle');
    if (langToggle) {
        langToggle.checked = (savedLanguage === 'or');
    }
    updateLanguage(savedLanguage);

    // --- WELCOME POPUP LOGIC ---
    // Show popup only if it's the home page and it hasn't been shown in this session
    if (window.location.pathname.endsWith('index.html') || window.location.pathname.endsWith('/')) {
        if (!sessionStorage.getItem('welcomePopupShown')) {
            setTimeout(() => openModal('welcome-popup'), 1500);
            sessionStorage.setItem('welcomePopupShown', 'true');
        }
    }
    
    // --- EVENT LISTENERS ---

    if (langToggle) {
        langToggle.addEventListener('change', function() {
            const newLang = this.checked ? 'or' : 'en';
            updateLanguage(newLang);
        });
    }
    
    if (mainSupportBtn && chatbotContainer && closeChatbotBtn) {
        mainSupportBtn.addEventListener('click', () => {
            const isDisplayed = chatbotContainer.style.display === 'flex';
            chatbotContainer.style.display = isDisplayed ? 'none' : 'flex';
            if (!isDisplayed && chatbotMessages.innerHTML === '') {
                initializeChatbot();
            }
        });
        closeChatbotBtn.addEventListener('click', () => {
            chatbotContainer.style.display = 'none';
        });
    }

    const watchTutorialBtn = document.getElementById('watch-tutorial-btn');
    if (watchTutorialBtn) {
        watchTutorialBtn.addEventListener('click', () => {
            closeModal(document.getElementById('welcome-popup'));
            openModal('tutorial-video-popup');
        });
    }

    const closeWelcomeBtn = document.getElementById('close-welcome-btn');
    if(closeWelcomeBtn) {
        closeWelcomeBtn.addEventListener('click', () => {
            closeModal(document.getElementById('welcome-popup'));
        });
    }

    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('nav a').forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });
});