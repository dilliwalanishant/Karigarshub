// A unique name for our cache
const CACHE_NAME = 'karigar-hub-cache-v1';

// The list of files we want to cache for offline use
const urlsToCache = [
  '/',
  '/index.html',
  '/learn.html',
  '/schemes.html',
  '/sell.html',
  '/education.html',
  '/support.html',
  '/style.css',
  '/script.js',
  '/images/Karigar\'s hub logo.jpg',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
  'https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap'
];

// 1. Installation: Open a cache and add the files to it
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
  );
});

// 2. Fetch: Intercept network requests
self.addEventListener('fetch', event => {
  event.respondWith(
    // Try to find a match in the cache first
    caches.match(event.request)
      .then(response => {
        // If a cached version is found, return it
        if (response) {
          return response;
        }
        // Otherwise, fetch from the network
        return fetch(event.request);
      }
    )
  );
});

// 3. Activation: Clean up old caches
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
